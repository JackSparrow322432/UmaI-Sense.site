# UmaiSense — деплой на Vercel

Монорепозиторий: `frontend/` (Vite + React) и `backend/` (Express + MongoDB) —
на Vercel это **два отдельных проекта**, оба созданные из одного репозитория,
каждый со своей настройкой Root Directory.

## Что изменено для Vercel (по сравнению с исходным кодом)

- `backend/src/createApp.ts` — сборка Express-приложения вынесена в отдельную функцию
  (без неё нельзя было переиспользовать роуты между обычным сервером и serverless-функцией).
- `backend/src/db.ts` — подключение к MongoDB и сиды (`seedMilestones`/`seedAdmin`/`createIndexes`)
  теперь кешируются через `global`, чтобы не переподключаться на каждый холодный старт.
- `backend/api/index.ts` — новая точка входа для Vercel (serverless-функция).
  `backend/src/index.ts` (обычный сервер) не тронут по сути — просто использует те же `createApp`/`connectDB`.
- `backend/vercel.json` и `frontend/vercel.json` — конфиг сборки и роутинга.
- CORS в `createApp.ts` теперь дополнительно разрешает любой `*.vercel.app` origin
  (у Vercel на каждый деплой/превью свой домен).

## Важно про бэкенд на Vercel

- **Загрузка изображений будет работать только через Cloudinary.** Локальный fallback
  (`/uploads` на диске) не переживёт serverless — файловая система эфемерна. Обязательно
  задайте `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`.
- MongoDB должна быть доступна из интернета (Atlas и т.п.) — локальный `mongodb://localhost`
  не подойдёт, Vercel не видит вашу локальную машину.

## Деплой

1. **GitHub** — запушить этот код в `https://github.com/JackSparrow322432/Umai-Sense-project.git` (ветка `main`).
2. **Backend project** на vercel.com → Add New → Project → импортировать тот же репозиторий →
   Root Directory = `backend` → Environment Variables: `MONGO_URI`, `JWT_SECRET`, `SMTP_*`,
   `CLOUDINARY_*`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `OPENAI_API_KEY`, `NODE_ENV=production`.
3. **Frontend project** — импортировать репозиторий ещё раз → Root Directory = `frontend` →
   Environment Variables: `VITE_API_URL=https://<url-бэкенд-проекта>.vercel.app/api`
   (узнать URL после шага 2).
4. (Необязательно) на backend-проекте добавить `CLIENT_URL=https://<url-фронтенд-проекта>.vercel.app` —
   не обязательно из-за wildcard для `*.vercel.app` в CORS, но не помешает для кастомного домена.
