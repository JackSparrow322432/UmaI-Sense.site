import 'dotenv/config';
import { createApp } from './createApp';
import { connectDB } from './db';

/**
 * Traditional entrypoint — used for `npm run dev` / `npm start` on a
 * regular Node host (VPS, Docker, Railway, Render, ...). Vercel does NOT
 * use this file; its serverless entrypoint is api/index.ts.
 */
const app = createApp();
const PORT = process.env.PORT || 5000;

connectDB()
  .then(() => {
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch((err: Error) => {
    console.error('DB connection error:', err.message);
    process.exit(1);
  });
