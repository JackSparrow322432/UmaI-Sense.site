import mongoose from 'mongoose';
import { seedMilestones } from './utils/seedMilestones';
import { seedAdmin } from './utils/seedAdmin';
import { createIndexes } from './utils/createIndexes';

/**
 * Cached DB connection + one-time bootstrap (seeding, indexes).
 *
 * Why this exists: on Vercel every request can hit a fresh serverless
 * function instance ("cold start"). Without caching, each cold start would
 * open a brand-new MongoDB connection and re-run the seed/index logic.
 * The cache lives on `global` so it survives across invocations of the same
 * warm instance (Node module state is reused between calls in one instance).
 * On a traditional long-running server (npm start on a VPS) this simply
 * connects once, exactly like before.
 */
interface MongooseCache {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
}

declare global {
  // eslint-disable-next-line no-var
  var _umaiSenseMongoose: MongooseCache | undefined;
}

const cached: MongooseCache = global._umaiSenseMongoose ?? { conn: null, promise: null };
global._umaiSenseMongoose = cached;

export const connectDB = async (): Promise<typeof mongoose> => {
  if (cached.conn) return cached.conn;

  if (!cached.promise) {
    cached.promise = mongoose
      .connect(process.env.MONGO_URI || 'mongodb://localhost:27017/umai_sense')
      .then(async (m) => {
        console.log('MongoDB connected');
        await seedMilestones();
        await seedAdmin();
        await createIndexes();
        return m;
      })
      .catch((err) => {
        // Reset the promise so the next request can retry instead of
        // being stuck with a rejected promise forever.
        cached.promise = null;
        throw err;
      });
  }

  cached.conn = await cached.promise;
  return cached.conn;
};
