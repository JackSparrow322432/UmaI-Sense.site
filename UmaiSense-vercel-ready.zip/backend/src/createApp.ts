import express from 'express';
import cors from 'cors';
import path from 'path';

import { connectDB } from './db';
import authRoutes from './routes/auth.routes';
import childrenRoutes from './routes/children.routes';
import invitesRoutes from './routes/invites.routes';
import emotionsRoutes from './routes/emotions.routes';
import activitiesRoutes from './routes/activities.routes';
import diaryRoutes from './routes/diary.routes';
import milestonesRoutes from './routes/milestones.routes';
import recommendationsRoutes from './routes/recommendations.routes';
import notificationsRoutes from './routes/notifications.routes';
import uploadRoutes from './routes/upload.routes';
import adminRoutes from './routes/admin.routes';
import articlesRoutes from './routes/articles.routes';

/**
 * Builds the Express app. Used both by the traditional entrypoint
 * (src/index.ts, for a VPS/Node host) and the Vercel serverless entrypoint
 * (api/index.ts) — the route wiring lives in exactly one place.
 */
export const createApp = () => {
  const app = express();

  const allowedOrigins = [
    'https://umai-sense.netlify.app',
    ...(process.env.CLIENT_URL ? [process.env.CLIENT_URL] : []),
    'http://localhost:5173',
    'http://localhost:5174',
    'http://localhost:5175',
  ];

  app.use(
    cors({
      origin: (origin, callback) => {
        const isAllowed =
          !origin ||
          allowedOrigins.includes(origin) ||
          /\.vercel\.app$/.test(new URL(origin).hostname); // Vercel preview + prod deployments
        if (isAllowed) callback(null, true);
        else callback(new Error('Not allowed by CORS'));
      },
      credentials: true,
    })
  );
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

  // Ensure the DB is connected (and seeded) before any route runs.
  // No-op after the first successful call within a warm instance.
  app.use(async (_req, res, next) => {
    try {
      await connectDB();
      next();
    } catch (err) {
      console.error('DB connection error:', err);
      res.status(503).json({ message: 'Database unavailable' });
    }
  });

  app.use('/api/auth', authRoutes);
  app.use('/api/children', childrenRoutes);
  app.use('/api/invites', invitesRoutes);
  app.use('/api/emotions', emotionsRoutes);
  app.use('/api/activities', activitiesRoutes);
  app.use('/api/diary', diaryRoutes);
  app.use('/api/milestones', milestonesRoutes);
  app.use('/api/recommendations', recommendationsRoutes);
  app.use('/api/notifications', notificationsRoutes);
  app.use('/api/upload', uploadRoutes);
  app.use('/api/admin', adminRoutes);
  app.use('/api/articles', articlesRoutes);

  app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

  return app;
};
