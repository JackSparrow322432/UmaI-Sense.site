import 'dotenv/config';
import { createApp } from '../src/createApp';

/**
 * Vercel serverless entrypoint. Vercel auto-detects any file under /api
 * and deploys it as a function; an Express app is a valid request handler
 * (req, res) => void, so exporting it directly works with zero extra
 * config. vercel.json rewrites every request here so Express still sees
 * the original path (/api/auth/login etc.) and its routes match normally.
 */
const app = createApp();

export default app;
